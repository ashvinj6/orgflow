import { useState } from "react";
import { useMembers } from "../context/MembersContext";
import { useEvents } from "../context/EventsContext";
import { Card, SearchInput, Badge, Modal, Button, FormField, Input, Select } from "../components/UI";
import { getMemberAttendanceCount, getEngagementLevel, getEngagementColor } from "../data/mockData";

const ROLES = ["Member", "President", "VP Operations", "VP Academics", "Event Lead", "Committee Lead"];
const COMMITTEES = ["Executive", "Tech", "Events", "Outreach", "Finance", "Academics"];

export default function Members() {
  const { members, addMember, deleteMember } = useMembers();
  const { events, attendance } = useEvents();
  const [search, setSearch] = useState("");
  const [filterCommittee, setFilterCommittee] = useState("All");
  const [showAdd, setShowAdd] = useState(false);
  const [newMember, setNewMember] = useState({ name: "", role: "Member", committee: "Tech", major: "", email: "" });

  const pastEvents = events.filter((e) => new Date(e.date) <= new Date());

  const filtered = members.filter((m) => {
    const matchesSearch = m.name.toLowerCase().includes(search.toLowerCase()) || m.role.toLowerCase().includes(search.toLowerCase()) || m.major.toLowerCase().includes(search.toLowerCase());
    const matchesCommittee = filterCommittee === "All" || m.committee === filterCommittee;
    return matchesSearch && matchesCommittee;
  });

  const handleAdd = () => {
    if (!newMember.name.trim()) return;
    addMember({ ...newMember, joinDate: new Date().toISOString().split("T")[0] });
    setNewMember({ name: "", role: "Member", committee: "Tech", major: "", email: "" });
    setShowAdd(false);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 28, fontWeight: 800, margin: 0, color: "var(--text-primary, #0f172a)", letterSpacing: "-0.02em" }}>Members</h1>
          <p style={{ color: "var(--text-muted, #64748b)", marginTop: 4, fontSize: 14 }}>{members.length} total members</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>+ Add Member</Button>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
        <SearchInput value={search} onChange={setSearch} placeholder="Search members..." />
        <select
          value={filterCommittee}
          onChange={(e) => setFilterCommittee(e.target.value)}
          style={{ padding: "10px 14px", borderRadius: 8, border: "1px solid var(--border, #e2e8f0)", fontSize: 14, background: "var(--bg-card, #fff)", color: "var(--text-primary, #0f172a)" }}
        >
          <option value="All">All Committees</option>
          {COMMITTEES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Table */}
      <Card style={{ padding: 0, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
          <thead>
            <tr style={{ borderBottom: "2px solid var(--border, #e2e8f0)" }}>
              {["Name", "Role", "Committee", "Major", "Joined", "Attendance", "Engagement"].map((h) => (
                <th key={h} style={{ padding: "14px 16px", textAlign: "left", fontWeight: 600, color: "var(--text-muted, #64748b)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  {h}
                </th>
              ))}
              <th style={{ padding: "14px 16px", width: 60 }}></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((m) => {
              const count = getMemberAttendanceCount(m.id, attendance);
              const level = getEngagementLevel(count, pastEvents.length);
              return (
                <tr key={m.id} style={{ borderBottom: "1px solid var(--border, #f1f5f9)" }}>
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#6366f1", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, flexShrink: 0 }}>
                        {m.name.split(" ").map((n) => n[0]).join("")}
                      </div>
                      <div>
                        <div style={{ fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>{m.name}</div>
                        <div style={{ fontSize: 12, color: "var(--text-muted, #94a3b8)" }}>{m.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: "12px 16px", color: "var(--text-primary, #334155)" }}>{m.role}</td>
                  <td style={{ padding: "12px 16px", color: "var(--text-primary, #334155)" }}>{m.committee}</td>
                  <td style={{ padding: "12px 16px", color: "var(--text-primary, #334155)" }}>{m.major}</td>
                  <td style={{ padding: "12px 16px", color: "var(--text-muted, #94a3b8)", fontSize: 13 }}>
                    {new Date(m.joinDate).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
                  </td>
                  <td style={{ padding: "12px 16px", fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>
                    {count}/{pastEvents.length}
                  </td>
                  <td style={{ padding: "12px 16px" }}>
                    <Badge label={level} color={getEngagementColor(level)} />
                  </td>
                  <td style={{ padding: "12px 16px" }}>
                    <button onClick={() => deleteMember(m.id)} style={{ border: "none", background: "none", color: "#ef4444", cursor: "pointer", fontSize: 16 }} title="Remove">✕</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={{ padding: 40, textAlign: "center", color: "var(--text-muted, #94a3b8)" }}>No members found</div>
        )}
      </Card>

      {/* Add Member Modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add Member">
        <FormField label="Full Name"><Input value={newMember.name} onChange={(v) => setNewMember({ ...newMember, name: v })} placeholder="Jane Doe" /></FormField>
        <FormField label="Email"><Input value={newMember.email} onChange={(v) => setNewMember({ ...newMember, email: v })} placeholder="jane@university.edu" /></FormField>
        <FormField label="Role"><Select value={newMember.role} onChange={(v) => setNewMember({ ...newMember, role: v })} options={ROLES.map((r) => ({ value: r, label: r }))} /></FormField>
        <FormField label="Committee"><Select value={newMember.committee} onChange={(v) => setNewMember({ ...newMember, committee: v })} options={COMMITTEES.map((c) => ({ value: c, label: c }))} /></FormField>
        <FormField label="Major"><Input value={newMember.major} onChange={(v) => setNewMember({ ...newMember, major: v })} placeholder="Computer Science" /></FormField>
        <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", marginTop: 24 }}>
          <Button variant="secondary" onClick={() => setShowAdd(false)}>Cancel</Button>
          <Button onClick={handleAdd}>Add Member</Button>
        </div>
      </Modal>
    </div>
  );
}
