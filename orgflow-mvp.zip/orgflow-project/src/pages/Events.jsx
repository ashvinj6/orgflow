import { useState } from "react";
import { useEvents } from "../context/EventsContext";
import { Card, Button, Modal, FormField, Input, Select, Textarea, Badge } from "../components/UI";

const EVENT_TYPES = ["General Meeting", "Workshop", "Speaker Event", "Social", "Fundraiser", "Other"];

export default function Events() {
  const { events, attendance, addEvent, deleteEvent } = useEvents();
  const [showAdd, setShowAdd] = useState(false);
  const [tab, setTab] = useState("upcoming");
  const [newEvent, setNewEvent] = useState({ title: "", type: "General Meeting", date: "", time: "", location: "", description: "" });

  const now = new Date();
  const upcoming = events.filter((e) => new Date(e.date) > now).sort((a, b) => new Date(a.date) - new Date(b.date));
  const past = events.filter((e) => new Date(e.date) <= now).sort((a, b) => new Date(b.date) - new Date(a.date));
  const displayed = tab === "upcoming" ? upcoming : past;

  const typeColors = {
    "General Meeting": "#6366f1",
    Workshop: "#f59e0b",
    "Speaker Event": "#06b6d4",
    Social: "#22c55e",
    Fundraiser: "#ec4899",
    Other: "#6b7280",
  };

  const handleAdd = () => {
    if (!newEvent.title.trim() || !newEvent.date) return;
    addEvent(newEvent);
    setNewEvent({ title: "", type: "General Meeting", date: "", time: "", location: "", description: "" });
    setShowAdd(false);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 28, fontWeight: 800, margin: 0, color: "var(--text-primary, #0f172a)", letterSpacing: "-0.02em" }}>Events</h1>
          <p style={{ color: "var(--text-muted, #64748b)", marginTop: 4, fontSize: 14 }}>{events.length} total events</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>+ Create Event</Button>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, marginBottom: 24, background: "var(--bg-card, #fff)", borderRadius: 10, padding: 4, width: "fit-content", border: "1px solid var(--border, #e2e8f0)" }}>
        {["upcoming", "past"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              padding: "8px 20px",
              borderRadius: 8,
              border: "none",
              cursor: "pointer",
              fontSize: 14,
              fontWeight: 600,
              background: tab === t ? "#6366f1" : "transparent",
              color: tab === t ? "#fff" : "var(--text-muted, #64748b)",
            }}
          >
            {t === "upcoming" ? `Upcoming (${upcoming.length})` : `Past (${past.length})`}
          </button>
        ))}
      </div>

      {/* Event Cards */}
      <div style={{ display: "grid", gap: 16 }}>
        {displayed.map((e) => {
          const attendeeCount = (attendance[e.id] || []).length;
          return (
            <Card key={e.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
                  <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "var(--text-primary, #0f172a)" }}>{e.title}</h3>
                  <Badge label={e.type} color={typeColors[e.type] || "#6b7280"} />
                </div>
                <div style={{ display: "flex", gap: 24, fontSize: 13, color: "var(--text-muted, #64748b)" }}>
                  <span>📅 {new Date(e.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}</span>
                  {e.time && <span>🕐 {e.time}</span>}
                  <span>📍 {e.location}</span>
                  <span>👥 {attendeeCount} attended</span>
                </div>
                {e.description && (
                  <p style={{ margin: "8px 0 0", fontSize: 13, color: "var(--text-muted, #94a3b8)", maxWidth: 600 }}>{e.description}</p>
                )}
              </div>
              <button onClick={() => deleteEvent(e.id)} style={{ border: "none", background: "none", color: "#ef4444", cursor: "pointer", fontSize: 18, padding: "8px", flexShrink: 0 }} title="Delete">✕</button>
            </Card>
          );
        })}
        {displayed.length === 0 && (
          <Card style={{ textAlign: "center", color: "var(--text-muted, #94a3b8)", padding: 48 }}>
            {tab === "upcoming" ? "No upcoming events. Create one!" : "No past events yet."}
          </Card>
        )}
      </div>

      {/* Add Event Modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Create Event">
        <FormField label="Event Title"><Input value={newEvent.title} onChange={(v) => setNewEvent({ ...newEvent, title: v })} placeholder="Monthly General Meeting" /></FormField>
        <FormField label="Event Type"><Select value={newEvent.type} onChange={(v) => setNewEvent({ ...newEvent, type: v })} options={EVENT_TYPES.map((t) => ({ value: t, label: t }))} /></FormField>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <FormField label="Date"><Input type="date" value={newEvent.date} onChange={(v) => setNewEvent({ ...newEvent, date: v })} /></FormField>
          <FormField label="Time"><Input value={newEvent.time} onChange={(v) => setNewEvent({ ...newEvent, time: v })} placeholder="6:00 PM" /></FormField>
        </div>
        <FormField label="Location"><Input value={newEvent.location} onChange={(v) => setNewEvent({ ...newEvent, location: v })} placeholder="Student Union Room 201" /></FormField>
        <FormField label="Description"><Textarea value={newEvent.description} onChange={(v) => setNewEvent({ ...newEvent, description: v })} placeholder="What's this event about?" /></FormField>
        <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", marginTop: 24 }}>
          <Button variant="secondary" onClick={() => setShowAdd(false)}>Cancel</Button>
          <Button onClick={handleAdd}>Create Event</Button>
        </div>
      </Modal>
    </div>
  );
}
