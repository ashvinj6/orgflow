import { useMembers } from "../context/MembersContext";
import { useEvents } from "../context/EventsContext";
import { useNotes } from "../context/NotesContext";
import { StatCard, Card } from "../components/UI";
import { getMemberAttendanceCount, getEngagementLevel, getEngagementColor } from "../data/mockData";

export default function Dashboard({ onNavigate }) {
  const { members } = useMembers();
  const { events, attendance } = useEvents();
  const { notes } = useNotes();

  const pastEvents = events.filter((e) => new Date(e.date) <= new Date());
  const upcomingEvents = events.filter((e) => new Date(e.date) > new Date());

  // Calculate active members (attended at least 1 event)
  const activeMembers = members.filter(
    (m) => getMemberAttendanceCount(m.id, attendance) > 0
  );

  // Average attendance per event
  const avgAttendance =
    pastEvents.length > 0
      ? (Object.values(attendance).reduce((sum, a) => sum + a.length, 0) / pastEvents.length).toFixed(1)
      : 0;

  // Top 5 most active members
  const membersByActivity = members
    .map((m) => ({ ...m, count: getMemberAttendanceCount(m.id, attendance) }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Low engagement members
  const lowEngagement = members.filter((m) => {
    const count = getMemberAttendanceCount(m.id, attendance);
    const level = getEngagementLevel(count, pastEvents.length);
    return level === "Low" || level === "Inactive";
  });

  return (
    <div>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--text-primary, #0f172a)", margin: 0, letterSpacing: "-0.02em" }}>
          Dashboard
        </h1>
        <p style={{ color: "var(--text-muted, #64748b)", marginTop: 4, fontSize: 14 }}>
          Overview of your organization's health
        </p>
      </div>

      {/* Stat Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 32 }}>
        <StatCard label="Total Members" value={members.length} sublabel={`${activeMembers.length} active`} />
        <StatCard label="Events" value={events.length} sublabel={`${upcomingEvents.length} upcoming`} />
        <StatCard label="Avg Attendance" value={avgAttendance} sublabel="per event" />
        <StatCard label="Notes" value={notes.length} sublabel="officer notes" />
      </div>

      {/* Two Column Layout */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Most Active */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "var(--text-primary, #0f172a)" }}>Most Active Members</h3>
            <button onClick={() => onNavigate("insights")} style={{ border: "none", background: "none", color: "#6366f1", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              View All →
            </button>
          </div>
          {membersByActivity.map((m, i) => (
            <div key={m.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", borderBottom: i < 4 ? "1px solid var(--border, #f1f5f9)" : "none" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#6366f1", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>
                  {m.name.split(" ").map((n) => n[0]).join("")}
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>{m.name}</div>
                  <div style={{ fontSize: 12, color: "var(--text-muted, #94a3b8)" }}>{m.role}</div>
                </div>
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#6366f1" }}>{m.count} events</div>
            </div>
          ))}
        </Card>

        {/* Low Engagement */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "var(--text-primary, #0f172a)" }}>Needs Attention</h3>
            <span style={{ fontSize: 12, color: "#ef4444", fontWeight: 600 }}>{lowEngagement.length} members</span>
          </div>
          {lowEngagement.length === 0 ? (
            <p style={{ color: "var(--text-muted, #94a3b8)", fontSize: 14 }}>All members are engaged!</p>
          ) : (
            lowEngagement.slice(0, 5).map((m, i) => {
              const count = getMemberAttendanceCount(m.id, attendance);
              const level = getEngagementLevel(count, pastEvents.length);
              return (
                <div key={m.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", borderBottom: i < Math.min(lowEngagement.length, 5) - 1 ? "1px solid var(--border, #f1f5f9)" : "none" }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>{m.name}</div>
                    <div style={{ fontSize: 12, color: "var(--text-muted, #94a3b8)" }}>{m.committee}</div>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 600, color: getEngagementColor(level), background: `${getEngagementColor(level)}18`, padding: "3px 10px", borderRadius: 20 }}>
                    {level}
                  </span>
                </div>
              );
            })
          )}
        </Card>

        {/* Upcoming Events */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "var(--text-primary, #0f172a)" }}>Upcoming Events</h3>
            <button onClick={() => onNavigate("events")} style={{ border: "none", background: "none", color: "#6366f1", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              View All →
            </button>
          </div>
          {upcomingEvents.length === 0 ? (
            <p style={{ color: "var(--text-muted, #94a3b8)", fontSize: 14 }}>No upcoming events. Time to plan one!</p>
          ) : (
            upcomingEvents.slice(0, 4).map((e, i) => (
              <div key={e.id} style={{ padding: "10px 0", borderBottom: i < Math.min(upcomingEvents.length, 4) - 1 ? "1px solid var(--border, #f1f5f9)" : "none" }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>{e.title}</div>
                <div style={{ fontSize: 12, color: "var(--text-muted, #94a3b8)", marginTop: 2 }}>
                  {new Date(e.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })} · {e.location}
                </div>
              </div>
            ))
          )}
        </Card>

        {/* Recent Notes */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "var(--text-primary, #0f172a)" }}>Recent Notes</h3>
            <button onClick={() => onNavigate("notes")} style={{ border: "none", background: "none", color: "#6366f1", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              View All →
            </button>
          </div>
          {notes.slice(0, 3).map((n, i) => (
            <div key={n.id} style={{ padding: "10px 0", borderBottom: i < 2 ? "1px solid var(--border, #f1f5f9)" : "none" }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>{n.title}</div>
              <div style={{ fontSize: 12, color: "var(--text-muted, #94a3b8)", marginTop: 2 }}>
                {n.author} · {n.category}
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}
