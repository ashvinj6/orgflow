import { useState } from "react";
import { useMembers } from "../context/MembersContext";
import { useEvents } from "../context/EventsContext";
import { Card, SearchInput } from "../components/UI";

export default function Attendance() {
  const { members } = useMembers();
  const { events, attendance, toggleAttendance, getEventAttendees } = useEvents();
  const [selectedEvent, setSelectedEvent] = useState(events[0]?.id || "");
  const [search, setSearch] = useState("");

  const event = events.find((e) => e.id === selectedEvent);
  const attendees = getEventAttendees(selectedEvent);

  const filteredMembers = members.filter((m) =>
    m.name.toLowerCase().includes(search.toLowerCase())
  );

  const attendedCount = attendees.length;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, margin: 0, color: "var(--text-primary, #0f172a)", letterSpacing: "-0.02em" }}>Attendance</h1>
        <p style={{ color: "var(--text-muted, #64748b)", marginTop: 4, fontSize: 14 }}>Track who showed up to each event</p>
      </div>

      {/* Event Selector */}
      <div style={{ display: "flex", gap: 12, marginBottom: 24, alignItems: "center" }}>
        <select
          value={selectedEvent}
          onChange={(e) => setSelectedEvent(e.target.value)}
          style={{
            padding: "10px 14px",
            borderRadius: 8,
            border: "1px solid var(--border, #e2e8f0)",
            fontSize: 14,
            background: "var(--bg-card, #fff)",
            color: "var(--text-primary, #0f172a)",
            flex: 1,
            maxWidth: 400,
          }}
        >
          {events.map((e) => (
            <option key={e.id} value={e.id}>
              {e.title} — {new Date(e.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
            </option>
          ))}
        </select>
        <SearchInput value={search} onChange={setSearch} placeholder="Search members..." />
      </div>

      {/* Summary */}
      {event && (
        <Card style={{ marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "var(--text-primary, #0f172a)" }}>{event.title}</h3>
            <div style={{ fontSize: 13, color: "var(--text-muted, #64748b)", marginTop: 4 }}>
              {new Date(event.date).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })} · {event.location}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 28, fontWeight: 700, color: "#6366f1" }}>{attendedCount}</div>
            <div style={{ fontSize: 12, color: "var(--text-muted, #64748b)" }}>of {members.length} attended</div>
          </div>
        </Card>
      )}

      {/* Member Checklist */}
      <Card style={{ padding: 0, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
          <thead>
            <tr style={{ borderBottom: "2px solid var(--border, #e2e8f0)" }}>
              <th style={{ padding: "14px 16px", width: 50, textAlign: "center" }}>
                <span style={{ fontSize: 12, color: "var(--text-muted, #64748b)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>✓</span>
              </th>
              {["Name", "Role", "Committee"].map((h) => (
                <th key={h} style={{ padding: "14px 16px", textAlign: "left", fontWeight: 600, color: "var(--text-muted, #64748b)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredMembers.map((m) => {
              const attended = attendees.includes(m.id);
              return (
                <tr
                  key={m.id}
                  onClick={() => toggleAttendance(selectedEvent, m.id)}
                  style={{
                    borderBottom: "1px solid var(--border, #f1f5f9)",
                    cursor: "pointer",
                    background: attended ? "rgba(99,102,241,0.04)" : "transparent",
                    transition: "background 0.1s ease",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = attended ? "rgba(99,102,241,0.08)" : "rgba(0,0,0,0.02)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = attended ? "rgba(99,102,241,0.04)" : "transparent")}
                >
                  <td style={{ padding: "12px 16px", textAlign: "center" }}>
                    <div
                      style={{
                        width: 22,
                        height: 22,
                        borderRadius: 6,
                        border: attended ? "none" : "2px solid var(--border, #cbd5e1)",
                        background: attended ? "#6366f1" : "transparent",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        margin: "0 auto",
                        color: "#fff",
                        fontSize: 14,
                        fontWeight: 700,
                        transition: "all 0.15s ease",
                      }}
                    >
                      {attended && "✓"}
                    </div>
                  </td>
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 30, height: 30, borderRadius: "50%", background: attended ? "#6366f1" : "#cbd5e1", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>
                        {m.name.split(" ").map((n) => n[0]).join("")}
                      </div>
                      <span style={{ fontWeight: 600, color: "var(--text-primary, #0f172a)" }}>{m.name}</span>
                    </div>
                  </td>
                  <td style={{ padding: "12px 16px", color: "var(--text-primary, #334155)" }}>{m.role}</td>
                  <td style={{ padding: "12px 16px", color: "var(--text-primary, #334155)" }}>{m.committee}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
