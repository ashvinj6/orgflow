import { createContext, useContext, useState } from "react";
import { MOCK_NOTES } from "../data/mockData";

const NotesContext = createContext();

export function NotesProvider({ children }) {
  const [notes, setNotes] = useState(MOCK_NOTES);

  const addNote = (note) => {
    const newNote = { ...note, id: `n${Date.now()}`, date: new Date().toISOString().split("T")[0] };
    setNotes((prev) => [newNote, ...prev]);
    return newNote;
  };

  const updateNote = (id, updates) => {
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, ...updates } : n)));
  };

  const deleteNote = (id) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <NotesContext.Provider value={{ notes, addNote, updateNote, deleteNote }}>
      {children}
    </NotesContext.Provider>
  );
}

export function useNotes() {
  const ctx = useContext(NotesContext);
  if (!ctx) throw new Error("useNotes must be used within NotesProvider");
  return ctx;
}
