import { createContext, useContext, useState } from "react";
import { MOCK_EVENTS, MOCK_ATTENDANCE } from "../data/mockData";

const EventsContext = createContext();

export function EventsProvider({ children }) {
  const [events, setEvents] = useState(MOCK_EVENTS);
  const [attendance, setAttendance] = useState(MOCK_ATTENDANCE);

  const addEvent = (event) => {
    const newEvent = { ...event, id: `e${Date.now()}` };
    setEvents((prev) => [...prev, newEvent]);
    setAttendance((prev) => ({ ...prev, [newEvent.id]: [] }));
    return newEvent;
  };

  const updateEvent = (id, updates) => {
    setEvents((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates } : e)));
  };

  const deleteEvent = (id) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
    setAttendance((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  };

  const toggleAttendance = (eventId, memberId) => {
    setAttendance((prev) => {
      const current = prev[eventId] || [];
      const next = current.includes(memberId)
        ? current.filter((id) => id !== memberId)
        : [...current, memberId];
      return { ...prev, [eventId]: next };
    });
  };

  const getEventAttendees = (eventId) => attendance[eventId] || [];

  return (
    <EventsContext.Provider
      value={{ events, attendance, addEvent, updateEvent, deleteEvent, toggleAttendance, getEventAttendees }}
    >
      {children}
    </EventsContext.Provider>
  );
}

export function useEvents() {
  const ctx = useContext(EventsContext);
  if (!ctx) throw new Error("useEvents must be used within EventsProvider");
  return ctx;
}
