import { createContext, useContext, useState } from "react";
import { MOCK_MEMBERS } from "../data/mockData";

const MembersContext = createContext();

export function MembersProvider({ children }) {
  const [members, setMembers] = useState(MOCK_MEMBERS);

  const addMember = (member) => {
    const newMember = { ...member, id: `m${Date.now()}` };
    setMembers((prev) => [...prev, newMember]);
    return newMember;
  };

  const updateMember = (id, updates) => {
    setMembers((prev) => prev.map((m) => (m.id === id ? { ...m, ...updates } : m)));
  };

  const deleteMember = (id) => {
    setMembers((prev) => prev.filter((m) => m.id !== id));
  };

  return (
    <MembersContext.Provider value={{ members, addMember, updateMember, deleteMember }}>
      {children}
    </MembersContext.Provider>
  );
}

export function useMembers() {
  const ctx = useContext(MembersContext);
  if (!ctx) throw new Error("useMembers must be used within MembersProvider");
  return ctx;
}
