import { useState } from "react";
import Dashboard from "./pages/Dashboard";
import Members from "./pages/Members";
import Events from "./pages/Events";
import Attendance from "./pages/Attendance";
import Insights from "./pages/Insights";
import Notes from "./pages/Notes";
import Sidebar from "./components/Sidebar";
import { MembersProvider } from "./context/MembersContext";
import { EventsProvider } from "./context/EventsContext";
import { NotesProvider } from "./context/NotesContext";

const PAGES = {
  dashboard: { label: "Dashboard", icon: "◉", component: Dashboard },
  members: { label: "Members", icon: "◎", component: Members },
  events: { label: "Events", icon: "◈", component: Events },
  attendance: { label: "Attendance", icon: "◇", component: Attendance },
  insights: { label: "Insights", icon: "△", component: Insights },
  notes: { label: "Notes", icon: "▤", component: Notes },
};

export default function App() {
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const PageComponent = PAGES[currentPage].component;

  return (
    <MembersProvider>
      <EventsProvider>
        <NotesProvider>
          <div style={{ display: "flex", minHeight: "100vh", background: "var(--bg-primary)" }}>
            <Sidebar
              pages={PAGES}
              currentPage={currentPage}
              onNavigate={setCurrentPage}
              open={sidebarOpen}
              onToggle={() => setSidebarOpen(!sidebarOpen)}
            />
            <main
              style={{
                flex: 1,
                marginLeft: sidebarOpen ? 240 : 64,
                transition: "margin-left 0.3s ease",
                padding: "32px 40px",
                maxWidth: 1200,
              }}
            >
              <PageComponent onNavigate={setCurrentPage} />
            </main>
          </div>
        </NotesProvider>
      </EventsProvider>
    </MembersProvider>
  );
}
