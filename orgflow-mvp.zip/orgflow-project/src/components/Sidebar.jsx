export default function Sidebar({ pages, currentPage, onNavigate, open, onToggle }) {
  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        height: "100vh",
        width: open ? 240 : 64,
        background: "var(--bg-sidebar, #0f172a)",
        color: "var(--text-sidebar, #e2e8f0)",
        transition: "width 0.3s ease",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        zIndex: 100,
        borderRight: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: open ? "24px 20px" : "24px 12px",
          display: "flex",
          alignItems: "center",
          gap: 12,
          cursor: "pointer",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
        onClick={onToggle}
      >
        <div
          style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 800,
            fontSize: 16,
            color: "#fff",
            flexShrink: 0,
          }}
        >
          OF
        </div>
        {open && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, letterSpacing: "-0.02em" }}>OrgFlow</div>
            <div style={{ fontSize: 11, opacity: 0.5, marginTop: 1 }}>Student Org Hub</div>
          </div>
        )}
      </div>

      {/* Nav Items */}
      <div style={{ padding: "12px 8px", flex: 1 }}>
        {Object.entries(pages).map(([key, { label, icon }]) => {
          const active = currentPage === key;
          return (
            <button
              key={key}
              onClick={() => onNavigate(key)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                width: "100%",
                padding: open ? "10px 14px" : "10px 0",
                justifyContent: open ? "flex-start" : "center",
                border: "none",
                borderRadius: 8,
                cursor: "pointer",
                fontSize: 14,
                fontWeight: active ? 600 : 400,
                color: active ? "#fff" : "rgba(255,255,255,0.55)",
                background: active ? "rgba(99,102,241,0.2)" : "transparent",
                marginBottom: 2,
                transition: "all 0.15s ease",
              }}
              onMouseEnter={(e) => {
                if (!active) e.currentTarget.style.background = "rgba(255,255,255,0.05)";
              }}
              onMouseLeave={(e) => {
                if (!active) e.currentTarget.style.background = "transparent";
              }}
            >
              <span style={{ fontSize: 18, flexShrink: 0, width: 24, textAlign: "center" }}>{icon}</span>
              {open && <span>{label}</span>}
            </button>
          );
        })}
      </div>

      {/* Footer */}
      {open && (
        <div style={{ padding: "16px 20px", borderTop: "1px solid rgba(255,255,255,0.06)", fontSize: 11, opacity: 0.35 }}>
          OrgFlow MVP v0.1
        </div>
      )}
    </nav>
  );
}
