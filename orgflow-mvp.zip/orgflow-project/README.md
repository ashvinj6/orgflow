# OrgFlow MVP

An internal dashboard for student org officers to manage members, events, attendance, engagement, and officer notes.

## Quick Start

```bash
npm install
npm run dev
```

Opens at http://localhost:5173

## Project Structure

```
src/
├── main.jsx                   # Entry point
├── App.jsx                    # Router + layout
├── data/
│   └── mockData.js            # Mock data + helper functions
├── context/
│   ├── MembersContext.jsx     # Member state management
│   ├── EventsContext.jsx      # Events + attendance state
│   └── NotesContext.jsx       # Notes state
├── components/
│   ├── Sidebar.jsx            # Navigation sidebar
│   └── UI.jsx                 # Reusable components
└── pages/
    ├── Dashboard.jsx          # Overview metrics
    ├── Members.jsx            # Member directory
    ├── Events.jsx             # Event management
    ├── Attendance.jsx         # Attendance tracking
    ├── Insights.jsx           # Engagement analytics
    └── Notes.jsx              # Officer notes & handoff
```

## Next Steps (V2)
- Add a real backend (Supabase / Firebase)
- Authentication & role-based permissions
- Recruiting/applicant pipeline
- Email notifications
- Member-facing portal
